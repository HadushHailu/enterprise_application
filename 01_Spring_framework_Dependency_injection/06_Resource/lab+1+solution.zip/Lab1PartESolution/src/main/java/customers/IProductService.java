package customers;

public interface IProductService {
    public void addProduct(Product product);
}
