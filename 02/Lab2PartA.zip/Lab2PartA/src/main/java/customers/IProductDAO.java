package customers;

public interface IProductDAO {
    public abstract void save(Product product);
}
