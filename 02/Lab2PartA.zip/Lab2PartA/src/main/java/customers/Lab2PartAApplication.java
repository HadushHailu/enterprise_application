package customers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2PartAApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab2PartAApplication.class, args);
	}

}
