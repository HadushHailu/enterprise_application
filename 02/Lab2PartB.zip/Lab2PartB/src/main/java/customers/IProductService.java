package customers;

public interface IProductService {
    public abstract void addProduct(String productId, String name, double unitPrice);
}
