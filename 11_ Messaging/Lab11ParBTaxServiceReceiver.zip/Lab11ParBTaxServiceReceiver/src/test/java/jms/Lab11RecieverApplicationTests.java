package jms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab11RecieverApplicationTests {

	@Test
	void contextLoads() {
	}

}
